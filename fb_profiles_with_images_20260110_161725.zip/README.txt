Facebook Profiles Export
Generated: 2026-01-10 16:17:28

Contents:
- profiles.csv: 13 profiles in CSV format
- profiles.json: 13 profiles in JSON format
- images/: 13 profile pictures

Image Format:
- Filename: {fb_id}.jpg
- Source: Downloaded from fb_picture_url

Fields Included:
- fb_id: Facebook profile ID
- fb_name: Seller name
- fb_location_name: Location
- fb_join_date: Join date
- fb_active_listings_count: Active listings
- fb_picture_url: Original image URL
- local_picture_path: Local image path
- And more...

Note: Some fields may be NULL if not available for that seller.
