Facebook Profile Export
Generated: 2026-01-10 16:20:54

Contents:
- profiles.csv: Profile data in CSV format
- profiles.json: Profile data in JSON format
- images/: Profile pictures (13 images)
  - From local storage: 13
  - Downloaded from URLs: 0

Total Records: 33

Image Sources:
- Local images are from browser enrichment (stored in profile_images/)
- Downloaded images are fetched from browser_profile_pic_url column
